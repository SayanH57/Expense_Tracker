document.querySelector('form').addEventListener('submit', function(event) {
    var amount = document.getElementById('amount').value;
    if (amount <= 0) {
        alert("Amount should be positive.");
        event.preventDefault(); // Prevent form submission
    }
});

